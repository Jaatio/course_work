from PyQt5.QtWidgets import QMessageBox


def msgbox_critical(header, text):
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Critical)

    msg.setWindowTitle(header)
    msg.setText(text)
    msg.setStandardButtons(QMessageBox.Ok)

    return(msg.exec_())

