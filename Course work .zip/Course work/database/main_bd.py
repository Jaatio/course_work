import pymysql
import sys
import re
from PyQt5 import QtWidgets

#pyuic5 .\RA.ui -o .\RA.py
#connection1 =pymysql.connect(host='localhost',user='root',password='root',database='bd')

class Main_BdApi:

    def __init__(self):
        self.connection =pymysql.connect(host='localhost',
                                         user='root',
                                         password='1234',
                                         database='main_bd')
        try:
            with self.connection:
                self.cr = self.connection.cursor()
                self.cr.execute("SELECT VERSION()")
                version = self.cr.fetchone()
                print("Database version: {}".format(version[0]))
                print(self.connection.get_server_info())
        except:
            sys.exit()

    def add_user_PHface(self, _FIO, _email, _passport_series, _passport_number, _birth_date, _telephone):
        print("Добавление физ лица: ", _FIO, _email, _passport_series, _passport_number, _birth_date, _telephone)
        self.connection = pymysql.connect(host='localhost',
                                          user='root',
                                          password='1234',
                                          database='main_bd')
        with self.connection:
            self.cr = self.connection.cursor()
            self.cr.execute("SELECT VERSION()")
            version = self.cr.fetchone()
            print("Database version: {}".format(version[0]))
            print(self.connection.get_server_info())
            add_f = "INSERT INTO ph_face (FIO, email, passport_series, passport_number, birth_date, telephone) VALUES (%s, %s, %s, %s, %s, %s)"
            self.cr.execute(add_f, (_FIO, _email, _passport_series, _passport_number, _birth_date, _telephone))
            self.connection.commit()

    def get_services(self):
        self.connection = pymysql.connect(host='localhost',
                                     user='root',
                                     password='1234',
                                     database='main_bd')

        services = []
        with self.connection.cursor() as cursor:
            cursor.execute("SELECT Service_name FROM Services_prices")
            services = cursor.fetchall()
        return services

    def set_price(self, selected_service):
        self.connection = pymysql.connect(host='localhost',
                                          user='root',
                                          password='1234',
                                          database='main_bd')

        price = None
        with self.connection.cursor() as cursor:
            cursor.execute("SELECT Price FROM Services_prices WHERE Service_name = %s", (selected_service,))
            result = cursor.fetchone()
            if result:
                price = result[0]
        return price


    def add_user_URface(self, _company_name, _address, _INN, _RS, _BIK, _director_name, _contact_person_name,
                        _contact_phone, _contact_email):
        print("Добавление юр лица: ", _company_name, _address, _INN, _RS, _BIK, _director_name, _contact_person_name,
              _contact_phone, _contact_email)
        self.connection = pymysql.connect(host='localhost', user='root', password='1234', database='main_bd')


        with self.connection:
            self.cr = self.connection.cursor()
            self.cr.execute("SELECT VERSION()")
            version = self.cr.fetchone()
            print("Database version: {}".format(version[0]))
            print(self.connection.get_server_info())
            add_f = "INSERT INTO ur_face (company_name, address, INN, RS, BIK, director_name, contact_person_name, contact_phone, contact_email) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
            self.cr.execute(add_f, (
            _company_name, _address, _INN, _RS, _BIK, _director_name, _contact_person_name, _contact_phone,
            _contact_email))
            self.connection.commit()

    def add_Order(self, _Code_id, _Name_order, _Price, _Face_role, _Client_name):
        print("Добавление заказа: ", _Code_id, _Name_order, _Price, _Face_role)
        self.connection = pymysql.connect(host='localhost',
                                          user='root',
                                          password='1234',
                                          database='main_bd')
        with self.connection:
            self.cr = self.connection.cursor()
            self.cr.execute("SELECT VERSION()")
            version = self.cr.fetchone()
            print("Database version: {}".format(version[0]))
            print(self.connection.get_server_info())
            add_f = "INSERT INTO form_order (code_id,face_role, name_service,price_service, client_name) VALUES (%s, %s, %s, %s, %s)"

            self.cr.execute(add_f, (_Code_id,_Face_role, _Name_order, _Price, _Client_name))
            self.connection.commit()

    def set_next_lab_vessel_code(self):
        # Connect to the database
        self.connection = pymysql.connect(host='localhost',
                                          user='root',
                                          password='1234',
                                          database='main_bd')
        with self.connection:
            self.cr = self.connection.cursor()

            # Get the maximum code_id from the form_order table
            query = "SELECT MAX(code_id) FROM form_order"
            self.cr.execute(query)
            max_code_id = self.cr.fetchone()[0]

            # If no orders exist, set the next code to 1
            if max_code_id is None:
                next_code_id = 1
            else:
                next_code_id = max_code_id + 1

            return next_code_id
            # Set the placeholder text with the next code

    def check_client_name(self, _Face_role, _Client_name):
        if _Face_role == 'Юридическое лицо':
            return self.check_ur_face_name(_Face_role, _Client_name)
        elif _Face_role == 'Физическое лицо':
             self.check_ph_face_name(_Face_role, _Client_name)
        else:
            raise ValueError(f"Неизвестный тип лица: {_Face_role}")

    def check_ph_face_name(self,_Face_role, _Client_name):
        self.connection = pymysql.connect(host='localhost',
                                          user='root',
                                          password='1234',
                                          database='main_bd')
        # Use the existing connection
        cursor = self.connection.cursor()
        query = f"SELECT FIO FROM ph_face WHERE FIO LIKE '%{_Client_name}%'"
        cursor.execute(query)
        results = cursor.fetchall()

        if not results:
            # Клиент не найден
            print("false")
            msg = QtWidgets.QMessageBox()
            msg.setWindowTitle("Ошибка")
            msg.setText(f"Клиент '{_Client_name}' не найден в базе данных для выбранного типа лица: {_Face_role}")
            msg.exec_()
            return False
        else:
            # Клиент найден
            print("true")
            return True  # Возвращаем True, если клиент найден

    def check_ur_face_name(self,_Face_role, _Client_name):
        self.connection = pymysql.connect(host='localhost',
                                          user='root',
                                          password='1234',
                                          database='main_bd')
        # Use the existing connection
        cursor = self.connection.cursor()
        query = f"SELECT contact_person_name FROM ur_face WHERE contact_person_name LIKE '%{_Client_name}%'"
        cursor.execute(query)
        results = cursor.fetchall()

        if _Face_role =="Юридическое лицо":
            if not results:
                # Клиент не найден
                print("false")
                msg = QtWidgets.QMessageBox()
                msg.setWindowTitle("Ошибка")
                msg.setText(f"Клиент '{_Client_name}' не найден в базе данных для выбранного типа лица: {_Face_role}")
                msg.exec_()
                return False
            else:
                # Клиент найден
                print("true")
                return True  # Возвращаем True, если клиент найден


    def check_ur_face_duplicate(self, _INN, _BIK, _RS):
        self.connection = pymysql.connect(host='localhost', user='root', password='1234', database='main_bd')
        cursor = self.connection.cursor()
        cursor.execute("SELECT COUNT(*) FROM ur_face WHERE INN = %s AND BIK = %s AND RS = %s", (_INN, _BIK, _RS))
        count = cursor.fetchone()[0]
        cursor.close()
        return count > 0

Mbd = Main_BdApi()
