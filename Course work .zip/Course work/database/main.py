from PyQt5.QtWidgets import QMessageBox
from PyQt5 import QtWidgets
import pymysql
import sys
import re
#pyuic5 .\RA.ui -o .\RA.py
#connection1 =pymysql.connect(host='localhost',user='root',password='root',database='bd')
class BdApi:
    def __init__(self):

        self.connection = pymysql.connect(host='localhost',
                                         user='root',
                                         password='1234',
                                         database='main_bd')
        try:
            with self.connection:
                self.cr = self.connection.cursor()
                self.cr.execute("SELECT VERSION()")
                version = self.cr.fetchone()
                print("Database version: {}".format(version[0]))
                print(self.connection.get_server_info())
        except:
            sys.exit()

    def registration(self, _role, _login, _password, _fio, _phone):
        print("регистрация: ", _role, _login, _password)
        self.connection = pymysql.connect(host='localhost',
                                          user='root',
                                          password='1234',
                                          database='main_bd')
        with self.connection:
            self.cr = self.connection.cursor()
            self.cr.execute("SELECT VERSION()")
            version = self.cr.fetchone()
            print("Database version: {}".format(version[0]))
            print(self.connection.get_server_info())
            reg = "insert into user_info (role_log, login, password, fio, phone) values (%s, %s, %s, %s, %s)"

            self.cr.execute(reg, (_role, _login, _password, _fio, _phone))  # Remove self from the arguments
            self.connection.commit()

    def authorization(self, _login, _password):
        print("авторизация:", _login, _password)
        self.connection = pymysql.connect(host='localhost',
                                          user='root',
                                          password='1234',
                                          database='main_bd')
        with self.connection:
            self.cr = self.connection.cursor()
            log = f'''select login,password,role_log from user_info where login = %s and password = %s '''
            self.cr.execute(log, (_login, _password))
            result = self.cr.fetchone()
            if result:
                print("Вы авторизовались")
                role = result[2]
                return role
            else:
                print("Не корректный логин или пароль")
                msg = QMessageBox()
                msg.setWindowTitle("Error")
                msg.setText("Invalid login or password")
                msg.exec_()
                return None


    def show_all_users(self):
        print("show all user")
        self.connection = pymysql.connect(host='localhost', user='root', password='1234', database='main_bd')
        with self.connection:
            self.cr = self.connection.cursor()
            log = f'''select * from user_info '''
            self.cr.execute(log)
            result = self.cr.fetchall()
            for x in result:
                print(x)
            return result

    def create_order(self, _value1, _value2, _value3, _value4):
        print("Создание заказа")

    def drop_all_bd(self):
        print("Удаление СУБД")

    def create_new_table(self):
        print("Create new table")

    def add_data_to(self,_value1,_value2,_value3):
        print("add data to bd", _value1, _value2, _value3)


    def db_close(self):
        self.connection = pymysql.connect(host='localhost', user='root', password='root', database='main_bd')
        self.connection.close()


    def create_new_table(self):
        self.connection = pymysql.connect(host='localhost',
                                          user='root',
                                          password='1234',
                                          database='main_bd')
        with self.connection:
            print("New_table")
            self.cr = self.connection.cursor()
            #log = f'''insert into user_info values (23,'iuiu', 34.6) '''
            log = f'''
            create table users1 ( 
            id int(11) not null auto_increment,
            email varchar(255) collate utf8_bin NOT NULL,
            password varchar(255) COLLATE utf8_bin NOT NULL,
            PRIMARY KEY (id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin
            AUTO_INCREMENT=1 
            '''
            self.cr.execute(log)
            #self.connection.commit()


    def authorization_new(self,_login,_password):
        print("тест")


    def isValid(self,email):
        regex = re.compile(r'([A-Za-z0-9]+[.-_])*[A-Za-z0-9]+@[A-Za-z0-9-]+(\.[A-Z|a-z]{2,})+')
        if re.fullmatch(regex, email):
          print("Valid email")
          return True
        else:
            msg = QtWidgets.QMessageBox()
            msg.setWindowTitle("Ошибка")
            msg.setText(f"Неверная почта")
            msg.exec_()
            return False

    def get_ur_face_data(self):
        self.connection = pymysql.connect(host='localhost', user='root', password='1234', database='main_bd')

        try:
            with self.connection.cursor() as cursor:
                cursor.execute('SELECT * FROM ur_face')
                result = cursor.fetchall()
            return result
        except pymysql.err.InterfaceError as e:
            print(f"InterfaceError: {e}")
            return []  # Возвращаем пустой список в случае ошибки

    def get_ph_face_data(self):
        self.connection = pymysql.connect(host='localhost', user='root', password='1234', database='main_bd')

        try:
            with self.connection.cursor() as cursor:
                cursor.execute('SELECT * FROM ph_face')
                result = cursor.fetchall()
            return result
        except pymysql.err.InterfaceError as e:
            print(f"InterfaceError: {e}")
            return []  # Возвращаем пустой список в случае ошибки

    def update_ph_face_data(self, data):
        with self.connection.cursor() as cursor:
            cursor.execute(
                'UPDATE ph_face SET ' + ', '.join([f"{key} = %s" for key in data.keys()]) + ' WHERE Physicface_id = %s',
                list(data.values()) + [data['Phisicface_id']])
            self.connection.commit()

    def get_orders_data(self):
        self.connection = pymysql.connect(host='localhost', user='root', password='1234', database='main_bd')
        with self.connection.cursor() as cursor:
            cursor.execute("SELECT * FROM form_order")
            data = cursor.fetchall()
            cursor.close()
        return data

    def check_ph_face_duplicate(self, passport_series, passport_number):
        self.connection = pymysql.connect(host='localhost', user='root', password='1234', database='main_bd')
        with self.connection.cursor() as cursor:
            cursor.execute("SELECT COUNT(*) FROM ph_face WHERE Passport_series = %s AND Passport_number = %s",
                           (passport_series, passport_number,))
            count = cursor.fetchone()[0]
            cursor.close()
        return count > 0




# Handle database errors here (e.g., display e
    #SELECT * FROM people WHERE email NOT LIKE '%_@__%.__%'
Tbd = BdApi()
#Tbd.isValid("kdflkf@dk")
#Tbd.registration(*Tbd.get_input())
#Tbd.authorization("login_13","1jj23")
#Tbd.add_data_to(1,2,3)
#print(Tbd.show_all_users())
#Tbd.create_new_table()
#Tbd.reg_to("sfff","jfkdgk","jjkfj")







