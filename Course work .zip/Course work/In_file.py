from PyQt5 import QtWidgets
import sys
from database.main import BdApi
from forms_pyuic.login_dig import Ui_Dialog
from forms_pyuic.main_win import Ui_SecondWindow
from forms_pyuic.add_user import Ui_ThirdDlog

#C:\Users\LENOVO\PycharmProjects\sql\venv\Scripts
#C:\Users\LENOVO\AppData\Local\Programs\Python\Python310\Scripts

class Practic(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)

        self.bd_api = BdApi()
        self.setWindowTitle("Авторизация")



        all_users = []
        usersIDs = self.bd_api.show_all_users()
        print(len(usersIDs))
        self.ui.tableWidget.clear()
        self.ui.tableWidget.setRowCount(len(usersIDs))
        for i in range(len(usersIDs)):
            for j in range(3):
                self.ui.tableWidget.setItem(i, j, QtWidgets.QTableWidgetItem(str(usersIDs[i][j])))




        self.ui.pushButton_registration.clicked.connect(self.regist_in)
        self.ui.pushButton_login.clicked.connect(self.autor_in)


    def autor_in(self):
        print("r1")
        _login = self.ui.lineEdit_login.text().strip()
        _password = self.ui.lineEdit_Password.text().strip()
        print("r2")
        self.add_users_win()
        print("r3")


    def Main_win(self):
        self.Main_win = Ui_SecondWindow()
        self.Main_win.show()

    def add_users_win(self):
        self.Add_win = QtWidgets.QDialog()
        # Используем объект Ui_ThirdDlog для настройки этого QDialog
        ui = Ui_ThirdDlog()
        ui.setupUi(self.Add_win)
        #self.ui.clicked.connect(self.add_phisface)

        self.Add_win.show()

    def regist_in(self):

            print("r1")

            _fio = self.ui.lineEdit_FIO.text().strip()
            _login = self.ui.lineEdit_login.text().strip()
            _password = self.ui.lineEdit_Password.text().strip()
            _phone = self.ui.lineEdit_Telephone.text().strip()
            self.bd_api.registration(_login, _password, _fio, _phone)

            print("r2")


#self.setWindowTitle("Главное окно")



if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    first_w = Practic()

