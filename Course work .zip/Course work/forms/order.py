from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QDialog, QApplication
import sys
from forms_pyuic.add_user import Ui_ThirdDlog
from database.main_bd import Main_BdApi

class T_W(QtWidgets.QMainWindow):
    def __init__(self, parent=None):
        QtWidgets.QWidget.__init__(self)
        self.ui = Ui_ThirdDlog()
        self.ui.setupUi(self)
        self.bd_api_Main = Main_BdApi()



        self.ui.pushButton_PHf.clicked.connect(self.add_phisface)
        self.ui.pushButton_URf.clicked.connect(self.add_urface)



    def add_phisface(self):
        print("r1")
        _FIO = self.ui.lineEdit_FIO.text().strip()
        _email = self.ui.lineEdit_email.text().strip()
        _passport_series = self.ui.lineEdit_passport_series.text().strip()
        _passport_number = self.ui.lineEdit_passport_number.text().strip()
        _birth_date = self.ui.dateEdit_birth_date.text().strip()
        _telephone = self.ui.lineEdit_telephone.text().strip()
        self.bd_api_Main.add_user_PHface(_FIO, _email, _passport_series, _passport_number, _birth_date, _telephone)
        print("r2")

    def add_urface(self):
        print("r1")
        _company_name = self.ui.lineEdit_company_name.text().strip()
        _address = self.ui.lineEdit_address.text().strip()
        _INN = self.ui.lineEdit_INN.text().strip()
        _RS = self.ui.lineEdit_RS.text().strip()
        _BIK = self.ui.lineEdit_BIK.text().strip()
        _director_name = self.ui.lineEdit_director_name.text().strip()
        _contact_person_name = self.ui.lineEdit_contact_person_name.text().strip()
        _contact_phone = self.ui.lineEdit_contact_phone.text().strip()
        _contact_email = self.ui.lineEdit_contact_email.text().strip()
        self.bd_api_Main.add_user_URface(_company_name, _address, _INN, _RS, _BIK, _director_name, _contact_person_name, _contact_phone, _contact_email)
        print("r2")

    def test(self):
        print("r1")


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    myapp = T_W()
    myapp.show()
    sys.exit(app.exec())