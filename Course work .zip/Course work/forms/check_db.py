from PyQt5 import QtWidgets,QtGui,QtCore



class CheckThread(QtCore.QThread):
    mysignal = QtCore.pyqtSignal(str)

    def thr_login(self,_login,_password):
        _login(_login,_password, self.mysignal)

    def thr_register(self,_login,_password):
        _password(_login,_password, self.mysignal)