from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication, QMainWindow, QLineEdit, QVBoxLayout, QWidget, QDialog, QCompleter
from PyQt5.QtSql import QSqlDatabase, QSqlQuery
import sys
from forms_pyuic.form_order import Ui_Dialog
from database.main_bd import Main_BdApi
import sqlite3

class Form_ord(QtWidgets.QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        self.bd_api_Main = Main_BdApi()

        LineEdit_labcode = QLineEdit()
        #LineEdit_labcode.setPlaceholderText('3')

        # Подключаемся к базе данных
        self.db = QSqlDatabase.addDatabase("QSQLITE")
        self.db.setDatabaseName("main_db.db")
        self.db.open()

        # Получаем последний номер заказа
        query = QSqlQuery("SELECT * FROM form_order ORDER BY code_id DESC LIMIT 1")
        query.next()
        last_order_number = query.value(0)
        if last_order_number is None:
            last_order_number = 0
        next_order_number = last_order_number + 1

        # Создаем QCompleter и устанавливаем его на LineEdit_labcode
        completer = QCompleter([str(next_order_number)], self)
        self.ui.LineEdit_labcode.setPlaceholderText(completer)

        self.ui.PushButton_formorder.clicked.connect(self.add_order)

    def add_order(self):
        print("r1")
        _Code_id = self.ui.LineEdit_labcode.text().strip()
        _Name_order = self.ui.LineEdit_service.text().strip()
        _Price = self.ui.LineEdit_price.text().strip()
        self.bd_api_Main.add_Order(_Code_id, _Name_order, _Price)
        print("r2")


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    myapp = Form_ord()
    myapp.show()
    sys.exit(app.exec_())