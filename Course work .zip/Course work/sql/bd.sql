DROP DATABASE IF EXISTS bd;
create database bd;
use bd;

CREATE TABLE user_info (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_log ENUM('Менеджер', 'Лаборант', 'Контролер') NOT NULL,
    login VARCHAR(24),
    password VARCHAR(24),
    fio VARCHAR(150),
    phone VARCHAR(12),
    UNIQUE (login)

);


