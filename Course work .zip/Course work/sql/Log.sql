DROP DATABASE IF EXISTS bd;
create database bd;
use bd;

create table user_info(
login varchar(24),
password varchar(24),
fio varchar(150),
phone varchar(12));

