USE main_bd;
SELECT * FROM ur_face;