DROP DATABASE IF EXISTS main_bd;
create database main_bd;
use main_bd;

CREATE TABLE user_info (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_log ENUM('Менеджер', 'Лаборант', 'Контролер') NOT NULL,
    login VARCHAR(24),
    password VARCHAR(24),
    fio VARCHAR(150),
    phone VARCHAR(12),
    UNIQUE (login)

);


CREATE TABLE ur_face(
face_id INT AUTO_INCREMENT PRIMARY KEY,
company_name VARCHAR(60) NOT NULL,
address VARCHAR(60),
INN VARCHAR(50) NOT NULL,
RS VARCHAR (50) NOT NULL,
BIK VARCHAR (50) not null,
director_name VARCHAR (60),
contact_person_name VARCHAR(60) NOT NULL,
contact_phone VARCHAR(20) NOT NULL,
contact_email VARCHAR(255) NOT NULL,
UNIQUE (INN,  BIK)
);

CREATE TABLE ph_face (
  Phisicface_id INT AUTO_INCREMENT PRIMARY KEY,
  FIO VARCHAR(100) NOT NULL,
  email VARCHAR(100),
  passport_series VARCHAR(4) CHECK (LENGTH(passport_series) = 4),  -- Enforces 4-character length
  passport_number VARCHAR(6) CHECK (LENGTH(passport_number) = 6), -- Enforces 6-character length
  birth_date DATE,
  telephone VARCHAR(20),  -- Use VARCHAR to store telephone number (may include country code)
  UNIQUE (passport_series, passport_number)  -- Unique constraint on both series and number
);


CREATE TABLE Services_prices(
  Service_id INT auto_increment PRIMARY KEY,
  Service_name Varchar(100) NOT NULL,
  Price DECIMAL(20,2) NOT NULL
  
);
INSERT INTO Services_prices (Service_name, Price) VALUES
    ('Контроль качества продукции на производстве', 12500),
    ('Специализированные исследования', 11050),
    ('Контроль качества на сторонних предприятиях', 10000),
    ('Независимая техническая экспертиза состава полимерных материалов', 55400);

INSERT INTO ph_face (FIO, email, passport_series, passport_number, birth_date, telephone)
VALUES ('Peter Williams', 'peter.williams@gmail.com', 'AB12', '345678', '1980-01-01', '+1 (888) 888-8888'),
       ('Sarah Miller', 'sarah.miller@hotmail.com', 'CD34', '901234', '1990-07-14', '+1 (999) 999-9999');


CREATE TABLE form_order (
  order_id INT AUTO_INCREMENT PRIMARY KEY,
  code_id INT(10) NOT NULL,
  Services_id INT,
  face_role ENUM('Юридическое лицо', 'Физическое лицо') NOT NULL,
  name_service VARCHAR(100),
  price_service VARCHAR(100),
  client_name VARCHAR(100),
  ur_face_id INT,
  ph_face_id INT,
  user_info_id INT,
  UNIQUE (code_id, Services_id),
  FOREIGN KEY (Services_id) REFERENCES Services_prices(Service_id),
  FOREIGN KEY (ur_face_id) REFERENCES ur_face(face_id),
  FOREIGN KEY (ph_face_id) REFERENCES ph_face(Phisicface_id),
  FOREIGN KEY (user_info_id) REFERENCES user_info(id)

);