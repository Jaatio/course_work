from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QApplication, QAction,QTextEdit, QMenuBar,QMenu,QFileDialog, QMainWindow, QTableView, QLabel, QLineEdit, QPushButton, QVBoxLayout, QWidget, QTableWidgetItem, QTableWidget, QStackedWidget
from PyQt5.QtGui import QStandardItemModel,QStandardItem
import sys
import datetime
from forms_pyuic.start import Ui_start_system
from forms_pyuic.login_window import Ui_Dialog
from forms_pyuic.manager_win import Ui_Manager_win
from forms_pyuic.add_user import Ui_ThirdDlog
from database.main_bd import Main_BdApi
from database.main import BdApi
from forms_pyuic.form_order import Ui_Win_Form_order
from PyQt5.QtWidgets import QMessageBox
from forms_pyuic.output_users import Ui_System_users
from forms_pyuic.Win_for_lab_contr import Ui_Win_contr_lab
from PyQt5 import QtCore, QtGui, QtWidgets
import re
from forms_pyuic.Output_clients import Ui_Dialog_show_client_list
import pymysql
from forms_pyuic.show_orders_list import Ui_Show_orders
#pyuic5 .\Win_for_lab_contr.ui -o .\Win_for_lab_contr.py


class Practic(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)

        self.bd_api = BdApi()
        self.setWindowTitle("Авторизация")
        self.ui.comboBox_userRole.addItem("Менеджер")
        self.ui.comboBox_userRole.addItem("Лаборант ")
        self.ui.comboBox_userRole.addItem("Контролер")

        self.ui.lineEdit_Telephone.setInputMask("99999999999")

        self.ui.pushButton_registration.clicked.connect(self.regist_in)
        self.ui.pushButton_login.clicked.connect(self.autor_in)

    def autor_in(self):
        print("r1")
        _login = self.ui.lineEdit_login_1.text().strip()
        _password = self.ui.lineEdit_password_login.text().strip()

        print("r2")

        role = self.bd_api.authorization(_login, _password)
        if role == 'Менеджер':
            self.main_win_manager = self.main_win_manager_go()
        elif role in ['Контролер', 'Лаборант']:
            self.main_win_employee = self.main_win_other_go()
        else:
            print("Unknown role")


        print("r3")

    def main_win_manager_go(self):
        self.close()  # Закрыть текущее окно
        global manager_w
        manager_w = Manager_window()  # Создать экземпляр класса Practic
        manager_w.show()  # Отобразить окно Practic

    def main_win_other_go(self):
        self.close()  # Закрыть текущее окно
        global others_w
        others_w = contr_lab_window()  # Создать экземпляр класса Practic
        others_w.show()  # Отобразить окно Practic


    def regist_in(self):
        _fio = self.ui.lineEdit_FIO.text().strip()
        _login = self.ui.lineEdit_login.text().strip()
        _password = self.ui.lineEdit_Password.text().strip()
        _phone = self.ui.lineEdit_Telephone.text().strip()
        _role = self.ui.comboBox_userRole.currentText()  # Получаем выбранную роль из QComboBox

        if not _login or not _password or not _fio or not _phone:
            error_dialog = QMessageBox()
            error_dialog.setIcon(QMessageBox.Critical)
            error_dialog.setWindowTitle("Ошибка")
            error_dialog.setText("Заполните все необходимые поля")
            error_dialog.exec_()
            return

        # Вызываем метод регистрации с передачей роли
        self.bd_api.registration(_role, _login, _password, _fio, _phone)

class Output_info_win(QtWidgets.QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_System_users()
        self.ui.setupUi(self)
        self.bd_api = BdApi()

        all_users = self.bd_api.show_all_users()

        # Set the table column count based on the number of columns in user_info table
        self.ui.tableWidget.setColumnCount(len(all_users[0]))  # Assuming all rows have the same number of columns

        # Set the table row count
        self.ui.tableWidget.setRowCount(len(all_users))

        # Set table headers (optional)
        headers = ["ID", "Role", "Login", "Password", "Full Name", "Phone"]  # Assuming column names
        self.ui.tableWidget.setHorizontalHeaderLabels(headers)

        # Populate table items
        for i, row in enumerate(all_users):
            for j, data in enumerate(row):
                self.ui.tableWidget.setItem(i, j, QtWidgets.QTableWidgetItem(str(data)))


class contr_lab_window(QtWidgets.QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_Win_contr_lab()
        self.ui.setupUi(self)

        self.ui.pushButton_Form_Order_lab_contr.clicked.connect(self.Form_Orders)
        self.ui.pushButton_report.clicked.connect(self.Form_Orders_for_lab_contr)
        self.ui.pushButton_exit.clicked.connect(self.main_win_back)
        self.ui.pushButton_clients_base_lab_lontr.clicked.connect(self.client_list_check)
        self.ui.pushButton_order_history_lab_contr.clicked.connect(self.Orders_list)
    #pushButton_exit


    def Form_Orders(self):
        global Form_order
        Form_order = Form_ord()  # Создать экземпляр класса Practic
        Form_order.show()  # Отобразить окно Practic

    def Form_Orders_for_lab_contr(self):
        global Form_order_l_c
        Form_order_l_c = Form_ord()  # Создать экземпляр класса Practic
        Form_order_l_c.show()

    def Form_Orders_for_lab_contr(self):
        global Form_report
        Form_report = TextEditor()  # Создать экземпляр класса Practic
        Form_report.show()

    def main_win_back(self):
        self.close()  # Закрыть текущее окно
        global login_win_go
        login_win_go = Practic()  # Создать экземпляр класса Practic
        login_win_go.show()  # Отобразить окно Practic

    def client_list_check(self):
        global client_output_win_go
        client_output_win_go = Output_info_clientlist_win()  # Создать экземпляр класса Practic
        client_output_win_go.show()  # Отобразить окно Practic

    def Orders_list(self):
        global Orders_list
        Orders_list = Show_orders()  # Создать экземпляр класса Practic
        Orders_list.show()  # Отобразить окно Practic


class Manager_window(QtWidgets.QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_Manager_win()
        self.ui.setupUi(self)
        self.ui.pushButton_exit.clicked.connect(self.main_win_back)

        self.ui.pushButton_Add_Client.clicked.connect(self.Add_Users)
        self.ui.pushButton_Form_Order.clicked.connect(self.Form_Orders)
        #self.ui.pushButton_order_history.clicked.connect()
        self.ui.pushButton_clients.clicked.connect(self.Form_Clients)

    def Add_Users(self):
        global Add_user
        Add_user = Window_Add_users()  # Создать экземпляр класса Practic
        Add_user.show()  # Отобразить окно Practic

    def Form_Orders(self):
        global Form_order
        Form_order = Form_ord()  # Создать экземпляр класса Practic
        Form_order.show()  # Отобразить окно Practic

    def Form_Clients(self):
        global Clients_output
        Clients_output = Output_info_win()  # Создать экземпляр класса Practic
        Clients_output.show()  # Отобразить окно Practic

    def main_win_back(self):
        self.close()  # Закрыть текущее окно
        global login_win_go
        login_win_go = Practic()  # Создать экземпляр класса Practic
        login_win_go.show()  # Отобразить окно Practic

class Window_Add_users(QtWidgets.QMainWindow):
    def __init__(self, parent=None):
        QtWidgets.QWidget.__init__(self)
        self.ui = Ui_ThirdDlog()
        self.ui.setupUi(self)
        self.bd_api_Main = Main_BdApi()
        self.bd_api = BdApi()

        self.ui.dateEdit_birth_date.setInputMask("9999-99-99")
        self.ui.lineEdit_telephone.setInputMask("99999999999")
        self.ui.lineEdit_passport_series.setInputMask("9999")
        self.ui.lineEdit_passport_number.setInputMask("999999")

        self.ui.lineEdit_INN.setInputMask("999999999999")
        self.ui.lineEdit_RS.setInputMask("99999999999999999999")
        self.ui.lineEdit_BIK.setInputMask("999999999")

        _INN = self.ui.lineEdit_INN.text().strip()
        _RS = self.ui.lineEdit_RS.text().strip()
        _BIK = self.ui.lineEdit_BIK.text().strip()
        self.ui.pushButton_PHf.clicked.connect(self.add_phisface)
        self.ui.pushButton_URf.clicked.connect(self.add_urface)



    def add_phisface(self):
        print("r1")
        _FIO = self.ui.lineEdit_FIO.text().strip()
        _email = self.ui.lineEdit_email.text().strip()
        _passport_series = self.ui.lineEdit_passport_series.text().strip()
        _passport_number = self.ui.lineEdit_passport_number.text().strip()
        _birth_date = self.ui.dateEdit_birth_date.text().strip()
        _telephone = self.ui.lineEdit_telephone.text().strip()



        if not _FIO or not _email or not _passport_series or not _passport_number or not _birth_date or not _telephone:
            error_dialog = QMessageBox()
            error_dialog.setIcon(QMessageBox.Critical)
            error_dialog.setWindowTitle("Ошибка")
            error_dialog.setText("Заполните все необходимые поля")
            error_dialog.exec_()

        if not self.bd_api.isValid(_email):
            msg = QtWidgets.QMessageBox()
            msg.setWindowTitle("Ошибка")
            msg.setText("Неверный формат email. Пожалуйста, проверьте введенный адрес.")
            msg.setIcon(QtWidgets.QMessageBox.Critical)  # Optional: Error icon
            msg.exec_()
            return  # Prevent sending invalid data to API
        self.save_ph_face_data( _passport_series,_passport_number)

        self.bd_api_Main.add_user_PHface(_FIO, _email, _passport_series, _passport_number, _birth_date, _telephone)
        print("r2")

    def save_ph_face_data(self, _passport_series,_passport_number ):

            # Check for duplicate passport data
        is_duplicate = self.bd_api.check_ph_face_duplicate(_passport_series, _passport_number)

        if is_duplicate:
            QMessageBox.warning(self, "Ошибка", "Паспортные данные уже существуют в базе данных.")
            return  # Prevent saving if duplicate found


    def add_urface(self):
        print("r1")
        _company_name = self.ui.lineEdit_company_name.text().strip()
        _address = self.ui.lineEdit_address.text().strip()
        _INN = self.ui.lineEdit_INN.text().strip()
        _RS = self.ui.lineEdit_RS.text().strip()
        _BIK = self.ui.lineEdit_BIK.text().strip()
        _director_name = self.ui.lineEdit_director_name.text().strip()
        _contact_person_name = self.ui.lineEdit_contact_person_name.text().strip()
        _contact_phone = self.ui.lineEdit_contact_phone.text().strip()
        _contact_email = self.ui.lineEdit_contact_email.text().strip()


        if not _company_name or not _address or not _INN or not _RS or not _BIK or not _director_name or not _contact_person_name or not _contact_phone or not _contact_email:
            error_dialog = QMessageBox()
            error_dialog.setIcon(QMessageBox.Critical)
            error_dialog.setWindowTitle("Ошибка")
            error_dialog.setText("Заполните все необходимые поля")
            error_dialog.exec_()
            return

        self.check_12_digits(_INN,_RS,_BIK)

        if self.bd_api_Main.check_ur_face_duplicate(_INN, _RS, _BIK):
            QMessageBox.warning(self, "Ошибка", "Дубликат ИНН, БИК или Р/С обнаружен.")
            return

        self.bd_api_Main.add_user_URface(_company_name, _address, _INN, _RS, _BIK, _director_name, _contact_person_name,
                                         _contact_phone, _contact_email)
    def check_12_digits(self, _INN, _RS, _BIK):
        lineEdit_INN = self.sender()
        lineEdit_RS = self.sender()
        lineEdit_BIK = self.sender()

        text1 = lineEdit_INN.text()
        text2 = lineEdit_RS.text()
        text3 = lineEdit_BIK.text()

        regex = r'\d{12}'
        segex = r'\d{20}'
        regex = r'\d{9}'

        if re.search(regex, text1):
            print("1")
        elif re.search(segex, text2):
            print("2")
        elif re.search(regex, text3):
            print("3")
        else:

            error_dialog = QMessageBox()
            error_dialog.setIcon(QMessageBox.Critical)
            error_dialog.setWindowTitle("Ошибка")
            error_dialog.setText("Не все поля заполнены верно")
            error_dialog.exec_()
            return




class Form_ord(QtWidgets.QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_Win_Form_order()
        self.ui.setupUi(self)
        self.bd_api_Main = Main_BdApi()
        self.ui.comboBox_change_face.addItem("Юридическое лицо")
        self.ui.comboBox_change_face.addItem("Физическое лицо")

        self.ui.PushButton_formorder.clicked.connect(self.add_order)


        services = self.bd_api_Main.get_services()  # Получение списка услуг из базы данных
        for service in services:
            self.ui.comboBox_services.addItem(service[0])  # Добавление названия услуги в combobox


        # Подключение слота для обработки изменений в combobox
        self.ui.comboBox_services.currentIndexChanged.connect(self.display_price)

        self.next_code_id = self.bd_api_Main.set_next_lab_vessel_code()
        self.update_lab_vessel_code_text()

    def check_client_name(self):
        selected_face_role = self.ui.comboBox_change_face.currentText()
        entered_name = self.ui.LineEdit_client_db.text()

        if selected_face_role == 'Юридическое лицо':
            self.check_ur_face_name(entered_name)
        elif selected_face_role == 'Физическое лицо':
            self.check_ph_face_name(entered_name)
    def update_lab_vessel_code_text(self):
        self.ui.LineEdit_labcode.setText(str(self.next_code_id))


    def display_price(self):
        selected_service = self.ui.comboBox_services.currentText()
        price = self.bd_api_Main.set_price(selected_service)
        if price is not None:
            self.ui.label_price.setText(str(price))
        else:
            self.ui.label_price.setText("Цена не найдена")

    def add_order(self):
        print("r1")
        _Code_id = self.ui.LineEdit_labcode.text().strip()
        _Name_order = self.ui.comboBox_services.currentText()
        _Price = self.ui.label_price.text()
        _Face_role = self.ui.comboBox_change_face.currentText()
        _Client_name = self.ui.LineEdit_client_db.text().strip()



        self.bd_api_Main.check_client_name(_Face_role, _Client_name)

        self.bd_api_Main.add_Order(_Code_id, _Name_order, _Price, _Face_role, _Client_name)
        print("r2")

        # Проверка наличия имени клиента в базе данных

class Output_info_clientlist_win(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Dialog_show_client_list()  # Assuming Ui_Dialog_show_client_list defines the UI elements
        self.ui.setupUi(self)

        self.bd_api = BdApi()
        self.model = QtGui.QStandardItemModel(self)  # Use QStandardItemModel
        self.current_data_type = "ur_face"  # Initial data type to display
        self.ui.tableView_clients_list.setModel(self.model)
        # Assuming you've set the model for tableView_clients_list in Ui_Dialog_show_client_list
        self.populate_table()

        self.ui.pushButton_update_clients.clicked.connect(self.change_data_type)

    def populate_table(self):
        try:
            data = []
            if self.current_data_type == "ur_face":
                data = self.bd_api.get_ur_face_data()
            else:
                data = self.bd_api.get_ph_face_data()

            print(f"Fetched data: {data}")  # Check if data is retrieved

            # Assuming you have set the model for tableView_clients_list
            self.model.clear()  # Clear existing data
            self.model.setHorizontalHeaderLabels(self.get_headers(self.current_data_type))  # Set headers

            for row in data:
                items = [QStandardItem(str(item)) for item in row]
                self.model.appendRow(items)  # Add row to the model

        except (pymysql.err.InterfaceError, pymysql.err.OperationalError) as e:
            print(f"Error fetching data: {e}")
            # Handle database connection errors here

    def change_data_type(self):
        if self.current_data_type == "ur_face":
            self.current_data_type = "ph_face"
            self.ui.pushButton_update_clients.setText("Показать юр лица")
        else:
            self.current_data_type = "ur_face"
            self.ui.pushButton_update_clients.setText("Показать физ лица")

        self.populate_table()

    def get_headers(self, data_type):
        if data_type == "ur_face":
            return ["Company Name", "Address", "INN", "RS", "BIK", "Contact Person Name", "Phone", "Email"]
        else:
            return ["Full Name", "Email", "Passport Series", "Passport Number", "Birth Date", "Phone"]

class Show_orders(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Show_orders()
        self.ui.setupUi(self)

        self.bd_api = BdApi()
        self.model = QtGui.QStandardItemModel(self)


        self.ui.tableView_order_list.setModel(self.model)

        self.orders_table()

    def orders_table(self):
        try:
            data = self.bd_api.get_orders_data()  # Replace with your actual API method

            self.model.clear()  # Clear existing data
            self.model.setHorizontalHeaderLabels(self.get_headers())

            for row in data:
                # Create QStandardItem objects from each item in the row
                items = [QStandardItem(str(item)) for item in row]
                self.model.appendRow(items)

        except (pymysql.err.InterfaceError, pymysql.err.OperationalError) as e:
            print(f"Error fetching data: {e}")
            # Handle database connection errors here

    def get_headers(self):
        return [
            "Order ID",
            "Code ID",
            "Service ID",
            "Client Role",
            "Service Name",
            "Service Price",
            "Client Name",
            "Company ID (if Юридическое лицо)",
            "Physical Face ID (if Физическое лицо)",
        ]




#------------------------------------------------------------dno_text_edit-----------------------------------------------
class TextEditor(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Simple Text Editor')

        # Create text area
        self.text_area = QTextEdit(self)
        self.setCentralWidget(self.text_area)

        # Create menu bar
        self.menu_bar = QMenuBar(self)
        self.file_menu = QMenu('Файл', self)

        # Add menu actions
        self.new_action = QAction('Новый', self, triggered=self.new_file)
        self.open_action = QAction('Открыть', self, triggered=self.open_file)
        self.save_action = QAction('Сохранить', self, triggered=self.save_file)
        self.exit_action = QAction('Выход', self, triggered=self.close)

        self.file_menu.addAction(self.new_action)
        self.file_menu.addAction(self.open_action)
        self.file_menu.addAction(self.save_action)
        self.file_menu.addSeparator()
        self.file_menu.addAction(self.exit_action)

        self.menu_bar.addMenu(self.file_menu)
        self.setMenuBar(self.menu_bar)

    def new_file(self):
        self.text_area.clear()

    def open_file(self):
        try:
            file_path, _ = QFileDialog.getOpenFileName(self, 'Открыть файл', '', 'Файлы TXT (*.txt)')
            if file_path:
                with open(file_path, 'r') as file:
                    self.text_area.setText(file.read())
        except Exception as e:
            print(f'Error opening file: {e}')

    def save_file(self):
        try:
            file_path, _ = QFileDialog.getSaveFileName(self, 'Сохранить файл', '', 'Файлы TXT (*.txt)')
            if file_path:
                with open(file_path, 'w') as file:
                    file.write(self.text_area.toPlainText())
        except Exception as e:
            print(f'Error saving file: {e}')

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    start_app = Practic()
    start_app.show()
    sys.exit(app.exec_())

 #global dialog
  #      dialog = QtWidgets.QDialog()
   #     dialog_ui = Ui_Dialog()
    #    dialog_ui.setupUi(dialog)
     #   dialog.show()

